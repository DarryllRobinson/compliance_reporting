const config = { apiUrl: "http://localhost:4000/api" };
export default config;
