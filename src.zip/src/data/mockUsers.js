export const users = [
  {
    id: 1,
    firstName: "John",
    surname: "Doe",
    email: "john@doe.com",
    jobTitle: "Financial Manager",
    phone: "123456789",
    mobile: "987654321",
    address: "123 Main St, Sydney, NSW 2000",
    role: "user",
    status: "active",
  },
];
