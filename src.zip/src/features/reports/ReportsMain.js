import { Box } from "@mui/material";

export default function ReportsMain() {
  return (
    <Box>
      <h1>Reports</h1>
      <p>List of reports will be here.</p>
    </Box>
  );
}
